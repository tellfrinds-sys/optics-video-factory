#!/usr/bin/env python3
"""مصنع فيديوهات منصة بوابة البصريات - نسخة خاصة أحادية المستخدم.

المسار المحكوم:
درس -> سكريبت -> SCRIPT_SCIENTIFIC -> مشاهد -> معاينة MP4 -> FINAL_VIDEO.
لا أفاتار متحرك، لا موسيقى، ولا نشر آلي.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import urllib.error
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse


ROOT = Path(os.environ.get("OPTICSGATE_FACTORY_ROOT", Path(__file__).resolve().parent)).resolve()
CONFIG_DIR = ROOT / "config"
DATA_DIR = ROOT / "data"
LESSONS_DIR = DATA_DIR / "lessons"
DEMO_DIR = DATA_DIR / "demo_payloads"
OUTPUTS_DIR = ROOT / "outputs"
ASSETS_DIR = ROOT / "assets"
BRAND_DIR = ASSETS_DIR / "brand"
DB_PATH = DATA_DIR / "factory.sqlite3"
INDEX_PATH = ROOT / "index.html"
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
DEFAULT_MODEL = os.environ.get("MODEL_NAME", "qwen2.5:7b-instruct")
MAX_BODY = 512 * 1024


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def dump_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def ensure_dirs() -> None:
    for path in (CONFIG_DIR, DATA_DIR, LESSONS_DIR, DEMO_DIR, OUTPUTS_DIR, ASSETS_DIR):
        path.mkdir(parents=True, exist_ok=True)


def config() -> dict[str, Any]:
    return {
        "factory": load_json(CONFIG_DIR / "factory.json"),
        "content": load_json(CONFIG_DIR / "content_rules.json"),
        "visual": load_json(CONFIG_DIR / "visual_identity.json"),
    }


class FactoryError(RuntimeError):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


class FactoryDB:
    def __init__(self, path: Path = DB_PATH):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def connect(self) -> sqlite3.Connection:
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def _init(self) -> None:
        with self.connect() as db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS lessons (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    audience TEXT NOT NULL,
                    target_duration_minutes INTEGER NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY,
                    lesson_id TEXT NOT NULL REFERENCES lessons(id),
                    status TEXT NOT NULL,
                    model TEXT NOT NULL,
                    version INTEGER NOT NULL DEFAULT 1,
                    script_json TEXT,
                    scene_plan_json TEXT,
                    preview_path TEXT,
                    publication_blocked INTEGER NOT NULL DEFAULT 1,
                    auto_publish INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS approvals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL REFERENCES jobs(id),
                    gate TEXT NOT NULL,
                    version INTEGER NOT NULL,
                    decision TEXT NOT NULL,
                    notes TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(job_id, gate, version)
                );
                CREATE TABLE IF NOT EXISTS revisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL REFERENCES jobs(id),
                    kind TEXT NOT NULL,
                    version INTEGER NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS audit_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT,
                    event TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                """
            )

    @staticmethod
    def _decode(row: sqlite3.Row | None) -> dict[str, Any] | None:
        if row is None:
            return None
        item = dict(row)
        for key in ("payload", "script_json", "scene_plan_json"):
            if key in item and item[key]:
                item[key] = json.loads(item[key])
        for key in ("publication_blocked", "auto_publish"):
            if key in item:
                item[key] = bool(item[key])
        return item

    def audit(self, event: str, job_id: str | None = None, payload: Any = None) -> None:
        with self.connect() as db:
            db.execute(
                "INSERT INTO audit_events(job_id,event,payload,created_at) VALUES(?,?,?,?)",
                (job_id, event, dump_json(payload or {}), now()),
            )

    def import_lesson(self, payload: dict[str, Any]) -> dict[str, Any]:
        required = ("id", "title", "audience", "target_duration_minutes", "topic_1", "topic_2", "topic_3")
        missing = [key for key in required if payload.get(key) in (None, "")]
        if missing:
            raise FactoryError(f"حقول الدرس الناقصة: {', '.join(missing)}")
        stamp = now()
        with self.connect() as db:
            db.execute(
                """INSERT INTO lessons(id,title,audience,target_duration_minutes,payload,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET title=excluded.title,audience=excluded.audience,
                   target_duration_minutes=excluded.target_duration_minutes,payload=excluded.payload,updated_at=excluded.updated_at""",
                (payload["id"], payload["title"], payload["audience"], int(payload["target_duration_minutes"]), dump_json(payload), stamp, stamp),
            )
        self.audit("LESSON_IMPORTED", payload={"lesson_id": payload["id"]})
        return self.get_lesson(payload["id"])

    def import_bundled_lessons(self) -> int:
        count = 0
        for path in sorted(LESSONS_DIR.glob("*.json")):
            self.import_lesson(load_json(path))
            count += 1
        return count

    def list_lessons(self) -> list[dict[str, Any]]:
        with self.connect() as db:
            rows = db.execute("SELECT * FROM lessons ORDER BY id").fetchall()
        return [self._decode(row) for row in rows]

    def get_lesson(self, lesson_id: str) -> dict[str, Any]:
        with self.connect() as db:
            row = db.execute("SELECT * FROM lessons WHERE id=?", (lesson_id,)).fetchone()
        item = self._decode(row)
        if not item:
            raise FactoryError("الدرس غير موجود", 404)
        return item

    def create_job(self, lesson_id: str, model: str = DEFAULT_MODEL) -> dict[str, Any]:
        self.get_lesson(lesson_id)
        job_id = f"JOB-{lesson_id}-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:5]}"
        stamp = now()
        with self.connect() as db:
            db.execute(
                "INSERT INTO jobs(id,lesson_id,status,model,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                (job_id, lesson_id, "DRAFT", model, stamp, stamp),
            )
        self.audit("JOB_CREATED", job_id, {"lesson_id": lesson_id, "model": model})
        return self.get_job(job_id)

    def list_jobs(self) -> list[dict[str, Any]]:
        with self.connect() as db:
            rows = db.execute(
                """SELECT jobs.*,lessons.title lesson_title,lessons.audience audience
                   FROM jobs JOIN lessons ON lessons.id=jobs.lesson_id ORDER BY jobs.created_at DESC"""
            ).fetchall()
        return [self._decode(row) for row in rows]

    def get_job(self, job_id: str) -> dict[str, Any]:
        with self.connect() as db:
            row = db.execute(
                """SELECT jobs.*,lessons.title lesson_title,lessons.audience audience
                   FROM jobs JOIN lessons ON lessons.id=jobs.lesson_id WHERE jobs.id=?""",
                (job_id,),
            ).fetchone()
            approvals = db.execute(
                "SELECT gate,version,decision,notes,created_at FROM approvals WHERE job_id=? ORDER BY id", (job_id,)
            ).fetchall()
        item = self._decode(row)
        if not item:
            raise FactoryError("مهمة الفيديو غير موجودة", 404)
        item["approvals"] = [dict(row) for row in approvals]
        return item

    def _update_job(self, job_id: str, **fields: Any) -> dict[str, Any]:
        if not fields:
            return self.get_job(job_id)
        fields["updated_at"] = now()
        values = [dump_json(value) if key in {"script_json", "scene_plan_json"} and value is not None else value for key, value in fields.items()]
        sql = ",".join(f"{key}=?" for key in fields)
        with self.connect() as db:
            cursor = db.execute(f"UPDATE jobs SET {sql} WHERE id=?", (*values, job_id))
        if cursor.rowcount != 1:
            raise FactoryError("مهمة الفيديو غير موجودة", 404)
        return self.get_job(job_id)

    def _revision(self, job_id: str, kind: str, version: int, payload: Any) -> None:
        with self.connect() as db:
            db.execute(
                "INSERT INTO revisions(job_id,kind,version,payload,created_at) VALUES(?,?,?,?,?)",
                (job_id, kind, version, dump_json(payload), now()),
            )

    def set_script(self, job_id: str, script: dict[str, Any], replace: bool = False) -> dict[str, Any]:
        job = self.get_job(job_id)
        if job["status"] == "FINAL_APPROVED":
            raise FactoryError("النسخة النهائية غير قابلة للكتابة فوقها", 409)
        version = job["version"]
        if job.get("script_json"):
            if not replace or job["status"] not in {"CHANGES_REQUESTED", "DRAFT"}:
                raise FactoryError("السكريبت موجود؛ أنشئ مراجعة جديدة بدل الكتابة فوقه", 409)
            version += 1
        self._revision(job_id, "SCRIPT", version, script)
        self.audit("SCRIPT_GENERATED", job_id, {"version": version})
        return self._update_job(
            job_id, version=version, script_json=script, scene_plan_json=None, preview_path=None,
            status="AWAITING_SCRIPT_SCIENTIFIC", publication_blocked=1,
        )

    def approve(self, job_id: str, gate: str, decision: str = "APPROVED", notes: str = "") -> dict[str, Any]:
        if gate not in {"SCRIPT_SCIENTIFIC", "FINAL_VIDEO"}:
            raise FactoryError("بوابة اعتماد غير صحيحة")
        if decision not in {"APPROVED", "CHANGES_REQUESTED"}:
            raise FactoryError("قرار الاعتماد غير صحيح")
        job = self.get_job(job_id)
        expected = "AWAITING_SCRIPT_SCIENTIFIC" if gate == "SCRIPT_SCIENTIFIC" else "AWAITING_FINAL_VIDEO"
        if job["status"] != expected:
            raise FactoryError(f"لا يمكن اعتماد {gate} عندما تكون الحالة {job['status']}", 409)
        with self.connect() as db:
            try:
                db.execute(
                    "INSERT INTO approvals(job_id,gate,version,decision,notes,created_at) VALUES(?,?,?,?,?,?)",
                    (job_id, gate, job["version"], decision, notes, now()),
                )
            except sqlite3.IntegrityError as exc:
                raise FactoryError("قرار هذه النسخة محفوظ بالفعل ولا يمكن تغييره", 409) from exc
        if decision == "CHANGES_REQUESTED":
            status, blocked = "CHANGES_REQUESTED", 1
        elif gate == "SCRIPT_SCIENTIFIC":
            status, blocked = "SCRIPT_APPROVED", 1
        else:
            status, blocked = "FINAL_APPROVED", 0
        self.audit("HUMAN_GATE_DECISION", job_id, {"gate": gate, "decision": decision, "version": job["version"]})
        return self._update_job(job_id, status=status, publication_blocked=blocked)

    def script_approved(self, job_id: str, version: int) -> bool:
        with self.connect() as db:
            row = db.execute(
                "SELECT 1 FROM approvals WHERE job_id=? AND gate='SCRIPT_SCIENTIFIC' AND version=? AND decision='APPROVED'",
                (job_id, version),
            ).fetchone()
        return bool(row)

    def set_scenes(self, job_id: str, scene_plan: dict[str, Any]) -> dict[str, Any]:
        job = self.get_job(job_id)
        if not self.script_approved(job_id, job["version"]):
            raise FactoryError("لا يمكن بناء المشاهد قبل اعتماد SCRIPT_SCIENTIFIC", 409)
        if job["status"] not in {"SCRIPT_APPROVED", "SCENES_READY"}:
            raise FactoryError(f"حالة المهمة لا تسمح ببناء المشاهد: {job['status']}", 409)
        validate_scene_plan(scene_plan)
        self._revision(job_id, "SCENE_PLAN", job["version"], scene_plan)
        self.audit("SCENE_PLAN_READY", job_id, {"version": job["version"], "scenes": len(scene_plan["scenes"])})
        return self._update_job(job_id, scene_plan_json=scene_plan, status="SCENES_READY", publication_blocked=1)

    def mark_preview(self, job_id: str, path: str) -> dict[str, Any]:
        job = self.get_job(job_id)
        if job["status"] not in {"SCENES_READY", "AWAITING_FINAL_VIDEO"}:
            raise FactoryError(f"لا يمكن إنشاء المعاينة في الحالة {job['status']}", 409)
        if any(a["gate"] == "FINAL_VIDEO" and a["version"] == job["version"] for a in job["approvals"]):
            raise FactoryError("قرار النسخة النهائية محفوظ؛ أنشئ مراجعة جديدة", 409)
        self.audit("PREVIEW_RENDERED", job_id, {"path": path, "version": job["version"]})
        return self._update_job(job_id, preview_path=path, status="AWAITING_FINAL_VIDEO", publication_blocked=1)

    def stats(self) -> dict[str, int]:
        with self.connect() as db:
            lessons = db.execute("SELECT COUNT(*) FROM lessons").fetchone()[0]
            jobs = db.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
            waiting = db.execute("SELECT COUNT(*) FROM jobs WHERE status LIKE 'AWAITING_%'").fetchone()[0]
            approved = db.execute("SELECT COUNT(*) FROM jobs WHERE status='FINAL_APPROVED'").fetchone()[0]
        return {"lessons_loaded": lessons, "jobs": jobs, "waiting_review": waiting, "final_approved": approved}


def http_json(url: str, payload: dict[str, Any] | None = None, timeout: float = 240) -> Any:
    data = None if payload is None else dump_json(payload).encode("utf-8")
    request = urllib.request.Request(
        url, data=data, method="GET" if payload is None else "POST",
        headers={"Content-Type": "application/json", "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.URLError as exc:
        raise FactoryError(f"تعذر الوصول إلى Ollama على {OLLAMA_HOST}: {exc.reason}", 503) from exc


def ollama_status() -> dict[str, Any]:
    try:
        result = http_json(f"{OLLAMA_HOST}/api/tags", timeout=4)
        return {"reachable": True, "models": [x.get("name") or x.get("model") for x in result.get("models", [])]}
    except Exception as exc:
        return {"reachable": False, "models": [], "error": str(exc)}


def extract_json(text: str) -> Any:
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        starts = [i for i in (text.find("{"), text.find("[")) if i >= 0]
        start = min(starts) if starts else -1
        end = max(text.rfind("}"), text.rfind("]"))
        if start < 0 or end <= start:
            raise FactoryError("لم يرجع النموذج JSON صالحًا", 502)
        return json.loads(text[start:end + 1])


def ollama_json(prompt: str, system: str, model: str) -> Any:
    result = http_json(
        f"{OLLAMA_HOST}/api/chat",
        {
            "model": model,
            "stream": False,
            "format": "json",
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
            "options": {"temperature": 0.2, "top_p": 0.9, "seed": 2026, "num_predict": 3000},
        },
    )
    return extract_json(result["message"]["content"])


def generate_script(db: FactoryDB, job_id: str) -> dict[str, Any]:
    job = db.get_job(job_id)
    lesson = db.get_lesson(job["lesson_id"])["payload"]
    rules = config()
    prompt = f"""حوّل الدرس التالي إلى بطاقة سكريبت كاملة لمنصة بوابة البصريات.
لا تضف معلومة علمية غير مرتبطة بالمصادر. اكتب JSON فقط بالحقول:
title, hook, learning_objectives, exclusions, opening, sections[], common_mistakes,
practical_summary, source_notice, closing_question, interactive_quiz, call_to_action,
signature, closing, scientific_review_flags.
كل section يحتوي heading,narration,on_screen,source_ids.

الدرس:
{json.dumps(lesson, ensure_ascii=False, indent=2)}

قواعد المحتوى:
{json.dumps(rules['content'], ensure_ascii=False, indent=2)}
"""
    script = ollama_json(prompt, "أنت محرر علمي مصري هادئ. الناتج مسودة تحتاج اعتمادًا بشريًا ولا يُنشر آليًا.", job["model"])
    if not isinstance(script, dict) or not script.get("sections"):
        raise FactoryError("بنية السكريبت الناتج غير صالحة", 502)
    return db.set_script(job_id, script)


def generate_scenes(db: FactoryDB, job_id: str, curated_demo: bool = False) -> dict[str, Any]:
    job = db.get_job(job_id)
    if curated_demo and job["lesson_id"] == "OG-PRACT-CL-001":
        plan = load_json(DEMO_DIR / "scene_plan.json")
    else:
        prompt = f"""حوّل السكريبت التالي إلى خطة مشاهد JSON لفيديو 1920x1080 بلا أفاتار وبلا موسيقى.
استخدم الهوية البصرية المرفقة نصيًا. الناتج: video_id,resolution,music,scenes[].
كل مشهد: id,type,title,narration,on_screen,visual_brief,duration_seconds,source_ids,medical_warning,sfx.
إجمالي النسخة النهائية 8-10 دقائق، والنص الظاهر قصير ومقروء.

السكريبت:
{json.dumps(job['script_json'], ensure_ascii=False, indent=2)}

الهوية:
{json.dumps(config()['visual'], ensure_ascii=False, indent=2)}
"""
        plan = ollama_json(prompt, "أنت مخرج فيديو تعليمي طبي دقيق. لا تحرك وجه المقدم ولا تستخدم موسيقى.", job["model"])
    return db.set_scenes(job_id, plan)


def validate_scene_plan(plan: dict[str, Any]) -> None:
    if not isinstance(plan, dict) or not isinstance(plan.get("scenes"), list) or not plan["scenes"]:
        raise FactoryError("خطة المشاهد فارغة أو غير صالحة")
    required = {"id", "type", "title", "narration", "on_screen", "visual_brief", "duration_seconds", "source_ids", "medical_warning", "sfx"}
    ids = set()
    for scene in plan["scenes"]:
        missing = required - set(scene)
        if missing:
            raise FactoryError(f"المشهد ينقصه: {', '.join(sorted(missing))}")
        if scene["id"] in ids:
            raise FactoryError(f"معرف مشهد مكرر: {scene['id']}")
        ids.add(scene["id"])
        if float(scene["duration_seconds"]) <= 0:
            raise FactoryError("مدة المشهد يجب أن تكون موجبة")
    if plan.get("music") not in (False, None):
        raise FactoryError("الموسيقى ممنوعة في هذا المصنع")


def _font(size: int, bold: bool = False):
    try:
        from PIL import ImageFont
    except ImportError as exc:
        raise FactoryError("Pillow غير مثبت؛ شغّل: pip install Pillow", 501) from exc
    name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    paths = [Path("/usr/share/fonts/truetype/dejavu") / name, Path("/usr/share/fonts/dejavu") / name]
    for path in paths:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.truetype(name, size)


def _wrap(draw, text: str, font, max_width: int) -> list[str]:
    words = str(text).split()
    lines, current = [], ""
    for word in words:
        candidate = f"{current} {word}".strip()
        width = draw.textbbox((0, 0), candidate, font=font, direction="rtl")[2]
        if current and width > max_width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


def _draw_rtl(draw, x: int, y: int, text: str, font, fill: str, max_width: int, spacing: int = 16) -> int:
    for line in _wrap(draw, text, font, max_width):
        draw.text((x, y), line, font=font, fill=fill, anchor="ra", direction="rtl", language="ar")
        y += font.size + spacing
    return y


def render_frame(scene: dict[str, Any], path: Path, index: int, total: int) -> None:
    try:
        from PIL import Image, ImageDraw
    except ImportError as exc:
        raise FactoryError("Pillow غير مثبت؛ شغّل: pip install Pillow", 501) from exc
    cfg = config()
    palette = cfg["visual"]["palette"]
    width, height = cfg["factory"]["render"]["width"], cfg["factory"]["render"]["height"]
    backgrounds = {
        "intro": palette["deep_navy"], "outro": palette["deep_navy"],
        "warning": palette["warning"], "scope": palette["charcoal"],
        "summary": palette["ivory"], "comparison": palette["navy"],
    }
    bg = backgrounds.get(scene["type"], palette["glass_teal"])
    light = scene["type"] == "summary"
    muted = palette["warm_taupe"] if light else palette["soft_sky"]
    image = Image.new("RGB", (width, height), bg)
    draw = ImageDraw.Draw(image)
    logo_path = ROOT / cfg["visual"]["brand_logo"]["primary_static"]
    if not logo_path.is_file():
        raise FactoryError("ملف شعار بوابة البصريات المعتمد غير موجود", 500)
    draw.rounded_rectangle((95, 120, 425, 450), radius=46, fill=palette["white"])
    logo = Image.open(logo_path).convert("RGBA")
    logo.thumbnail((300, 300), Image.Resampling.LANCZOS)
    image.paste(logo, (110 + (300 - logo.width) // 2, 135 + (300 - logo.height) // 2), logo)
    draw.rounded_rectangle((910, 110, 1810, 970), radius=46, fill=palette["ivory"] if not light else palette["white"])
    draw.text((1810, 66), "منصة بوابة البصريات | OpticsGate", font=_font(34, True), fill=muted, anchor="ra", direction="rtl")
    draw.text((140, 110), f"{index:02d}/{total:02d}", font=_font(32, True), fill=muted)
    _draw_rtl(draw, 1740, 190, scene["title"], _font(64, True), palette["deep_navy"], 760, 20)
    _draw_rtl(draw, 1740, 390, scene["on_screen"], _font(46, True), palette["glass_teal"], 760, 18)
    _draw_rtl(draw, 1740, 650, scene["visual_brief"], _font(30), palette["charcoal"], 760, 12)
    warning = scene.get("medical_warning") or ""
    if warning:
        draw.rounded_rectangle((940, 820, 1760, 910), radius=18, fill="#F3E4E1")
        _draw_rtl(draw, 1720, 842, warning, _font(25, True), palette["warning"], 720, 8)
    sources = " · ".join(scene.get("source_ids") or []) or "المصادر العلمية أسفل الفيديو"
    draw.text((1810, 1010), sources, font=_font(24), fill=muted, anchor="ra", direction="rtl")
    image.save(path, "PNG", optimize=True)


def render_preview(db: FactoryDB, job_id: str, scene_ids: list[str] | None = None) -> dict[str, Any]:
    job = db.get_job(job_id)
    if job["status"] not in {"SCENES_READY", "AWAITING_FINAL_VIDEO"}:
        raise FactoryError(f"لا يمكن الرندر في الحالة {job['status']}", 409)
    if not shutil.which("ffmpeg"):
        raise FactoryError("FFmpeg غير مثبت", 501)
    plan = job["scene_plan_json"]
    validate_scene_plan(plan)
    render_cfg = config()["factory"]["render"]
    out_dir = OUTPUTS_DIR / job_id / f"v{job['version']}"
    frames_dir = out_dir / "frames"
    frames_dir.mkdir(parents=True, exist_ok=True)
    selected = set(scene_ids or [])
    for index, scene in enumerate(plan["scenes"], 1):
        frame = frames_dir / f"{scene['id']}.png"
        if not selected or scene["id"] in selected or not frame.exists():
            render_frame(scene, frame, index, len(plan["scenes"]))
    concat_path = out_dir / "frames.txt"
    lines = []
    for scene in plan["scenes"]:
        frame = frames_dir / f"{scene['id']}.png"
        duration = min(float(scene["duration_seconds"]), float(render_cfg["preview_max_seconds_per_scene"]))
        escaped = str(frame.resolve()).replace("'", "'\\''")
        lines.extend([f"file '{escaped}'", f"duration {duration:.3f}"])
    last = str((frames_dir / f"{plan['scenes'][-1]['id']}.png").resolve()).replace("'", "'\\''")
    lines.append(f"file '{last}'")
    concat_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    manifest = {
        "job_id": job_id, "version": job["version"], "preview_only": True,
        "animated_avatar": False, "music": False, "resolution": "1920x1080",
        "scenes": plan["scenes"], "rendered_at": now(),
    }
    (out_dir / "render_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    video_path = out_dir / "storyboard_preview.mp4"
    command = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0",
        "-i", str(concat_path), "-vf", f"fps={render_cfg['fps']},format=yuv420p",
        "-c:v", "libx264", "-preset", "veryfast", "-movflags", "+faststart", str(video_path),
    ]
    result = subprocess.run(command, capture_output=True, text=True, timeout=180)
    if result.returncode != 0 or not video_path.exists():
        raise FactoryError(f"فشل FFmpeg: {result.stderr[-800:]}", 500)
    relative = "/" + video_path.relative_to(ROOT).as_posix()
    return db.mark_preview(job_id, relative)


def create_demo(db: FactoryDB) -> dict[str, Any]:
    lesson = db.import_lesson(load_json(LESSONS_DIR / "demo_soft_contact_lens.json"))
    job = db.create_job(lesson["id"], "curated-demo-no-ollama")
    return db.set_script(job["id"], load_json(DEMO_DIR / "script.json"))


def _pillow_available() -> bool:
    try:
        import PIL  # noqa: F401
        return True
    except ImportError:
        return False


def doctor(db: FactoryDB | None = None) -> dict[str, Any]:
    db = db or FactoryDB()
    db.import_bundled_lessons()
    cfg = config()
    refs = ASSETS_DIR / "visual_references"
    return {
        "factory": cfg["factory"]["factory_name"],
        "private_single_user": cfg["factory"]["private_single_user"],
        "animated_avatar": cfg["visual"]["avatar_policy"]["animated_avatar"],
        "music": cfg["content"]["music"],
        "auto_publish": cfg["content"]["auto_publish"],
        "resolution": cfg["visual"]["composition"]["resolution"],
        "reference_images": len(list(refs.glob("*.png"))),
        "approved_brand_logo": cfg["visual"]["brand_logo"]["primary_static"],
        "ffmpeg": shutil.which("ffmpeg"),
        "pillow": _pillow_available(),
        "ollama": ollama_status(),
        "database": db.stats(),
        "curriculum_baseline": cfg["factory"]["curriculum_baseline"],
    }


def _safe_path(base: Path, relative: str) -> Path | None:
    target = (base / unquote(relative).lstrip("/")).resolve()
    try:
        target.relative_to(base.resolve())
    except ValueError:
        return None
    return target if target.is_file() else None


class Handler(BaseHTTPRequestHandler):
    server_version = "OpticsGateVideoFactory/0.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        if os.environ.get("QUIET_HTTP") != "1":
            super().log_message(fmt, *args)

    def send_bytes(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; media-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, status: int, payload: Any) -> None:
        self.send_bytes(status, json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length < 0 or length > MAX_BODY:
            raise FactoryError("حجم الطلب غير صالح", 413)
        return json.loads(self.rfile.read(length).decode("utf-8")) if length else {}

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        try:
            db = FactoryDB()
            if path == "/":
                return self.send_bytes(200, INDEX_PATH.read_bytes(), "text/html; charset=utf-8")
            if path == "/health":
                return self.send_json(200, doctor(db))
            if path == "/api/config":
                return self.send_json(200, config())
            if path == "/api/lessons":
                return self.send_json(200, {"lessons": db.list_lessons()})
            if path == "/api/jobs":
                return self.send_json(200, {"jobs": db.list_jobs()})
            if path.startswith("/api/jobs/"):
                return self.send_json(200, db.get_job(path.split("/")[3]))
            if path.startswith("/assets/"):
                file = _safe_path(ASSETS_DIR, path[len("/assets/"):])
                if file:
                    return self.send_bytes(200, file.read_bytes(), "image/png")
            if path.startswith("/outputs/"):
                file = _safe_path(OUTPUTS_DIR, path[len("/outputs/"):])
                if file:
                    mime = "video/mp4" if file.suffix == ".mp4" else "application/json"
                    return self.send_bytes(200, file.read_bytes(), mime)
            return self.send_json(404, {"error": "المسار غير موجود"})
        except FactoryError as exc:
            return self.send_json(exc.status, {"error": str(exc)})
        except Exception as exc:
            return self.send_json(500, {"error": str(exc)})

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        try:
            payload = self.body()
            db = FactoryDB()
            if path == "/api/lessons":
                result = db.import_lesson(payload)
            elif path == "/api/jobs":
                result = db.create_job(payload["lesson_id"], payload.get("model", DEFAULT_MODEL))
            elif path == "/api/demo":
                result = create_demo(db)
            elif path.startswith("/api/jobs/"):
                parts = path.strip("/").split("/")
                if len(parts) != 4:
                    raise FactoryError("مسار المهمة غير صحيح", 404)
                job_id, action = parts[2], parts[3]
                if action == "generate-script":
                    result = generate_script(db, job_id)
                elif action == "approve-script":
                    result = db.approve(job_id, "SCRIPT_SCIENTIFIC", payload.get("decision", "APPROVED"), payload.get("notes", ""))
                elif action == "generate-scenes":
                    result = generate_scenes(db, job_id, bool(payload.get("curated_demo", False)))
                elif action == "render-preview":
                    result = render_preview(db, job_id, payload.get("scene_ids"))
                elif action == "approve-final":
                    result = db.approve(job_id, "FINAL_VIDEO", payload.get("decision", "APPROVED"), payload.get("notes", ""))
                else:
                    raise FactoryError("إجراء المهمة غير موجود", 404)
            else:
                raise FactoryError("المسار غير موجود", 404)
            return self.send_json(200, result)
        except FactoryError as exc:
            return self.send_json(exc.status, {"error": str(exc)})
        except (KeyError, ValueError, json.JSONDecodeError) as exc:
            return self.send_json(400, {"error": str(exc)})
        except Exception as exc:
            return self.send_json(500, {"error": str(exc)})


def serve(host: str, port: int) -> None:
    ensure_dirs()
    FactoryDB().import_bundled_lessons()
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"OpticsGate Video Factory: http://{host}:{port}")
    print("خاص بمستخدم واحد · لا أفاتار متحرك · لا موسيقى · لا نشر آلي")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


def main(argv: list[str] | None = None) -> int:
    ensure_dirs()
    parser = argparse.ArgumentParser(description="مصنع فيديوهات منصة بوابة البصريات")
    sub = parser.add_subparsers(dest="command", required=True)
    p_serve = sub.add_parser("serve")
    p_serve.add_argument("--host", default="127.0.0.1")
    p_serve.add_argument("--port", type=int, default=8000)
    sub.add_parser("doctor")
    p_demo = sub.add_parser("demo")
    p_demo.add_argument("--render", action="store_true")
    p_demo.add_argument("--approve-final", action="store_true")
    args = parser.parse_args(argv)
    db = FactoryDB()
    db.import_bundled_lessons()
    if args.command == "serve":
        serve(args.host, args.port)
    elif args.command == "doctor":
        print(json.dumps(doctor(db), ensure_ascii=False, indent=2))
    elif args.command == "demo":
        job = create_demo(db)
        job = db.approve(job["id"], "SCRIPT_SCIENTIFIC", notes="اعتماد اختباري صريح من CLI")
        job = generate_scenes(db, job["id"], curated_demo=True)
        if args.render:
            job = render_preview(db, job["id"])
        if args.approve_final:
            if not args.render:
                raise FactoryError("الاعتماد النهائي يتطلب --render")
            job = db.approve(job["id"], "FINAL_VIDEO", notes="اعتماد اختباري صريح من CLI")
        print(json.dumps(job, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
